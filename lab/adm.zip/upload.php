<?php 
include_once("classe/conection.php");
$arquivo = $_FILES['arquivo']['name'];
//pasta do arquivo
$_UP['pasta']='foto/';

?>